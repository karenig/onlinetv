-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 20, 2012 at 10:41 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tvintern_online`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=98 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `parent_id`, `title`) VALUES
(1, 0, 'news'),
(2, 1, 'hasarakutyun'),
(3, 1, 'qaxaqakanutyun'),
(4, 1, 'tntesutyun'),
(5, 1, 'mijazgayin'),
(6, 1, 'pataharner'),
(7, 1, 'krtutyun'),
(8, 1, 'gitutyun'),
(9, 1, 'business'),
(10, 1, 'sport'),
(11, 1, 'lifenews'),
(12, 1, 'interesting'),
(13, 1, 'mamul'),
(15, 0, 'films'),
(16, 15, 'haykakan'),
(17, 15, 'chtargmanvac'),
(18, 15, 'detektiv'),
(19, 15, 'drama'),
(20, 15, 'katakergutyun'),
(21, 15, 'yntanekan'),
(22, 15, 'triller'),
(23, 15, 'martafilm'),
(24, 15, 'patmakan'),
(25, 15, 'serial'),
(26, 15, 'sarsap'),
(27, 15, 'hndkakan'),
(28, 15, 'multfilmer'),
(29, 0, 'eighteen'),
(88, 0, 'xohanoc'),
(89, 88, 'Աղցաններ'),
(92, 88, 'Կարկանդակներ'),
(91, 88, 'Թխվածքներ'),
(90, 88, 'Անուշեղեն'),
(40, 0, 'blog'),
(41, 0, 'important_news'),
(42, 1, 'aroxjapahutyun'),
(43, 1, 'mshakuyt'),
(44, 0, 'horoskop'),
(46, 44, 'yndhanur'),
(47, 44, 'yst tarerqneri'),
(48, 44, 'erotik'),
(51, 0, 'serials'),
(52, 51, 'Գեներալի աղջիկը'),
(53, 51, 'Անուրջներ'),
(54, 51, 'Դժվար ապրուստ'),
(55, 51, 'Բանակում'),
(56, 51, 'Կարգին սերիալ'),
(57, 51, 'Հրեշտակների դպրոց'),
(58, 51, 'Ջեմիկը'),
(59, 51, 'Կյանքի կառուսել'),
(60, 51, 'Եղբայրներ'),
(61, 51, 'Ոստիկաններ'),
(62, 51, 'Վերվարածներն ընտանիքում'),
(63, 51, 'Մի ստիր'),
(64, 51, 'Անծանոթը'),
(65, 51, 'Տիգրանի մոլորակը'),
(66, 51, 'Եռաչափ սեր'),
(67, 0, 'tv_programs'),
(68, 67, 'Կիսաբաց լուսամուտներ'),
(69, 67, 'Ազատ գոտի'),
(70, 67, '32 ատամ'),
(71, 67, 'Քարից փափուկ'),
(72, 67, 'ինչ որտեղ երբ'),
(73, 67, 'Կենդանի մատյան'),
(74, 67, 'Հայացք ներսից'),
(75, 67, '02'),
(76, 67, 'Ուլտրամութ'),
(77, 67, 'Vitamin ակումբ'),
(78, 67, 'Երգ երգոց'),
(79, 67, 'Մի վնասիր'),
(80, 67, 'BLEF'),
(81, 67, 'Popհանրագիտարան'),
(82, 67, 'Sex - ը փոքր քաղաքում'),
(83, 67, 'Աշխարհի հայերը'),
(84, 67, 'Չէին սպասում'),
(85, 67, 'Երկրի գանձերը'),
(86, 67, 'Ժողովրդական երգիչ'),
(87, 67, 'Գեղեցկության ֆորում'),
(93, 88, 'Ըմպելիքներ'),
(94, 88, 'Ճաշատեսակներ'),
(95, 88, 'Պահածոներ'),
(96, 88, 'Պիցցա'),
(97, 88, 'Սենդվիչներ');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
